import 'dotenv/config';
import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  out: './drizzle',
  schema: './utils/schema.js',
  dialect: 'postgresql',
  dbCredentials: {
    url:'postgresql://neondb_owner:npg_TNyK6SmD3ULG@ep-long-tree-a5g3liwh-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require',
  },
});



