const { GoogleGenerativeAI } = require("@google/generative-ai");

const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
if (!apiKey) {
  throw new Error("Missing API Key: Please set NEXT_PUBLIC_GEMINI_API_KEY in your .env.local file");
}

const genAI = new GoogleGenerativeAI(apiKey);

const model = genAI.getGenerativeModel({
  model: "gemini-2.0-flash",
});

const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 40,
  maxOutputTokens: 8192,
  responseMimeType: "text/plain",
};

export const chatSession = {
  sendMessage: async (message) => {
    try {
      const chat = model.startChat({ generationConfig });
      const result = await chat.sendMessage(message);
      return result.response; 
    } catch (error) {
      console.error("Error in Gemini AI:", error);
      throw error;
    }
  },
};
