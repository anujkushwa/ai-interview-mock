import { SignUp } from '@clerk/nextjs';

export default function Page() {
  return (
    <section className="bg-gray-100 min-h-screen flex items-center justify-center p-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 w-full max-w-7xl bg-white shadow-2xl rounded-3xl overflow-hidden">
        {/* Left Side - Image & Welcome Text */}
        <div className="relative hidden lg:flex flex-col justify-center items-center p-12 bg-gradient-to-br from-indigo-600 to-purple-700 text-white text-center">
          <img
            src="https://thumbs.dreamstime.com/b/ai-artificial-intelligence-machine-learning-big-data-analysis-automation-technology-business-industrial-manufacturing-132528154.jpg"
            alt="Background"
            className="absolute inset-0 h-full w-full object-cover opacity-60"
          />
          <div className="relative z-10">
            <h2 className="text-5xl font-extrabold leading-tight drop-shadow-lg">Welcome To AI Mock Interview</h2>
            <p className="mt-4 text-xl font-medium opacity-90">Sign Up to continue your journey with us.</p>
          </div>
        </div>

        {/* Right Side - Sign In Section */}
        <div className="flex flex-col items-center justify-center p-10 sm:p-16 w-full">
          <h3 className="text-4xl font-bold text-gray-900 mb-6">Sign In</h3>
          <p className="text-gray-600 text-lg mb-6">Access your account and explore the features.</p>
          <div className="w-full max-w-md">
            <SignUp />
          </div>
          <p className="mt-6 text-gray-600 text-md">
            Don't have an account?{' '}
            <a href="/sign-up" className="text-indigo-600 font-semibold hover:underline">Sign up</a>
          </p>
        </div>
      </div>
    </section>
  );
}
