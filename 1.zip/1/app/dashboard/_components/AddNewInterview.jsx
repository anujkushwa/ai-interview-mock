"use client"

import React, { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { chatSession } from '@/utils/GeminiAIModal'
import { LoaderCircle } from 'lucide-react'
import { MockInterview } from '@/utils/schema'
import { v4 as uuidv4 } from 'uuid';
import { useUser } from '@clerk/nextjs'
import moment from 'moment'

function AddNewInterview() {
  const [openDialog, setOpenDialog] = useState(false)
  const [jobPosition, setJobPosition] = useState();
  const [jobDesc, setJobDesc] = useState();
  const [jobExperience, setJobExperience] = useState();
  const [loading, setLoading] = useState(false);
  const [jsonResponse, setJsonResponse] = useState([]);
  const { user } = useUser();

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const InputPrompt = `Job Position: ${jobPosition}, Job Description: ${jobDesc}, Years of Experience: ${jobExperience}. 
      Provide ${process.env.NEXT_PUBLIC_INTERVIEW_QUESTION_COUNT} interview questions with answers in JSON format.`;

    try {
      const result = await chatSession.sendMessage(InputPrompt);
      const MockJsonResp = (await result.text()).replace(/```json|```/g, "").trim();

      console.log(JSON.parse(MockJsonResp));
      setJsonResponse(MockJsonResp);

      const resp = await db.insert(MockInterview)
        .values({
          mockID: uuidv4(),
          jsonMockResp: MockJsonResp,
          jobPosition: jobPosition,
          jobDesc: jobDesc,
          jobExperience: jobExperience,
          createdBy: user?.primaryEmailAddress?.emailAddress,
          createdAt: moment().format('DD-MM-YYYY')
        }).returning({ mockID: MockInterview.mockId });

      console.log("insertID: ", resp)

      if (resp) {
        setOpenDialog(false);
      }


    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };


  return (
    <div>
      <div className='p-10 border rounded-lg bg-secondary hover:scale-105 hover:shadow-md cursor-pointer transition-all'
        onClick={() => setOpenDialog(true)}>
        <h2 className='font-bold text-lg text-center'>+ Add New</h2>
      </div>

      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className='max-w-2xl'>
          <DialogHeader>
            <DialogTitle className='text-2xl'>Tell us More about your Job interview</DialogTitle>
            <p className="text-sm text-muted-foreground">
              Add details about your job position/role, job description, and years of experience.
            </p>
          </DialogHeader>
          <div>
            <form onSubmit={onSubmit}>
              <div>
                <div className='mt-7 my-2'>
                  <label>Job Role / Job Position</label>
                  <Input placeholder="Ex. Fullstack Developer" required
                    onChange={(event) => setJobPosition(event.target.value)} />
                </div>

                <div className='my-4'>
                  <label>Job Description / Tech stack in short</label>
                  <Textarea placeholder="Ex. HTML, CSS, JS, DSA, DBMS, React.js, Node.js..." required
                    onChange={(event) => setJobDesc(event.target.value)} />
                </div>
              </div>

              <div className='my-3'>
                <label>Years of Experience </label>
                <Input placeholder="Ex. 0 to 5" type='number' max='55' required
                  onChange={(event) => setJobExperience(event.target.value)} />
              </div>

              <div className='flex gap-5 justify-end'>
                <Button type="button" variant="ghost" onClick={() => setOpenDialog(false)}>Cancel</Button>
                <Button type="submit" disabled={loading}>
                  {loading ?

                    <>
                      <LoaderCircle className='animate-spin' />'Generating from AI'
                    </> : 'start Interview'
                  }

                </Button>
              </div>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default AddNewInterview
