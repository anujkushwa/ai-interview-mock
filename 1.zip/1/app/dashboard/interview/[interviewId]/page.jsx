import React from 'react'

const Interview = () => {
  return (
    <div>Interview</div>
  )
}

export default Interview