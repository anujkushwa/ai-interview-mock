import Dashboard from "./dashboard/page";

export default function Home() {
  return (
    <div>
          <Dashboard />
    </div>
  );
}
